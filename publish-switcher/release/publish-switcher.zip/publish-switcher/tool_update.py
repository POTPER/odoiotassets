"""Verified, recoverable updates for Switcher itself. Compatible with Python 3.8."""
import argparse
import ast
from contextlib import contextmanager
import hashlib
import json
import logging
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import time
import urllib.parse
import urllib.error
import uuid
import zipfile

DEFAULT_UPDATE_URL = "https://gitee.com/potper/odoiotassets/raw/main/publish-switcher/release/switcher-update.json"
MAX_PACKAGE = 256 * 1024 * 1024
REQUIRED_FILES = ("switcher.py", "app.py", "core.py", "version.py", "tool_update.py", "install.sh",
                  "unified_update.py", "update_dialog.py")


class UpdateError(RuntimeError):
    pass


def version_number(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d+(?:\.\d+){1,4}", value):
        raise UpdateError("程序版本应为数字版本号，例如 2026.11.20.1。")
    return tuple(int(part) for part in value.split(".")) + (0,) * (5 - len(value.split(".")))


def https_url(value):
    if not isinstance(value, str):
        raise UpdateError("更新地址必须使用 HTTPS。")
    parsed = urllib.parse.urlsplit(value.strip())
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise UpdateError("更新地址必须是完整的 HTTPS 地址。")
    return value.strip()


def read_json(path):
    with Path(path).open(encoding="utf-8-sig") as stream:
        return json.load(stream)


def save_json(path, data):
    path = Path(path)
    temporary = path.with_name(path.name + ".writing")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    sync_directory(path.parent)


def sync_directory(path):
    if os.name == "posix":
        descriptor = os.open(str(path), os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


def update_state(install):
    install = Path(install).absolute()
    if install.is_symlink() or install == install.parent:
        raise UpdateError("程序安装目录不能是符号链接或文件系统根目录。")
    state = install.parent / ("." + install.name + "-updater")
    if state.is_symlink():
        raise UpdateError("程序更新目录不能是符号链接。")
    state.mkdir(exist_ok=True)
    return state


@contextmanager
def instance_lock(install, timeout=0):
    """Every GUI instance and the external update helper use the same lock."""
    path = update_state(install) / "instance.lock"
    deadline = time.monotonic() + timeout
    with path.open("a+b") as stream:
        if path.stat().st_size == 0:
            stream.write(b"0")
            stream.flush()
        while True:
            try:
                stream.seek(0)
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as exc:
                if time.monotonic() >= deadline:
                    raise UpdateError("另一个 Switcher 窗口或程序更新正在运行，请先关闭其他窗口。") from exc
                time.sleep(0.1)
        try:
            yield
        finally:
            if os.name == "nt":
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream, fcntl.LOCK_UN)


def validate_release(data):
    if not isinstance(data, dict) or data.get("schema_version") != 1 or data.get("product") != "publish-switcher":
        raise UpdateError("更新信息不是有效的 Switcher 发布信息。")
    version_number(data.get("version"))
    https_url(data.get("url"))
    if type(data.get("size")) is not int or not 0 < data["size"] <= MAX_PACKAGE:
        raise UpdateError("程序更新包大小无效或超过 256 MiB。")
    if not isinstance(data.get("sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", data["sha256"]):
        raise UpdateError("更新信息缺少有效的 SHA-256。")
    name = data.get("package_file", "publish-switcher.zip")
    if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_.-]+\.zip", name):
        raise UpdateError("离线更新包文件名无效。")
    result = dict(data, package_file=name)
    result["notes"] = str(data.get("notes", ""))[:8000]
    return result


def remote_file(url):
    """Preserve the existing Gitee public Blob fallback for ZIP downloads."""
    from core import Source
    parsed = urllib.parse.urlsplit(https_url(url))
    parts = parsed.path.strip("/").split("/")
    if parsed.hostname == "gitee.com" and len(parts) >= 5 and parts[2] == "raw" and not parsed.query:
        owner, repo, _, ref = parts[:4]
        try:
            source = (Source(owner=owner, repo=repo, commit=ref, provider="gitee") if re.fullmatch(r"[0-9a-f]{40}", ref)
                      else Source.remote("https://gitee.com/{}/{}".format(owner, repo), urllib.parse.unquote(ref)))
        except urllib.error.HTTPError as exc:
            if exc.code != 403:
                raise
            logging.getLogger("publish-switcher").warning(
                "Gitee API 返回 403，程序更新改为直接访问配置的公开文件地址；不切换仓库：%s", url)
            exc.close()
            # Publisher metadata supplies version, size and SHA-256. The package
            # must still pass all validation before replacing the installation.
            return Source(), url
        return source, urllib.parse.unquote("/".join(parts[4:]))
    return Source(), url


def mirror_locations(url, repositories=None):
    """Map only recognized repository raw URLs; external publisher URLs stay exact."""
    if not repositories:
        return [url]
    from repository_sources import normalize
    values = normalize(repositories)
    parsed = urllib.parse.urlsplit(https_url(url))
    parts = parsed.path.strip("/").split("/")
    origin = None
    if parsed.hostname == "gitee.com" and len(parts) >= 5 and parts[2] == "raw":
        origin, ref, path = "https://gitee.com/" + "/".join(parts[:2]), parts[3], "/".join(parts[4:])
    elif parsed.hostname == "raw.githubusercontent.com" and len(parts) >= 4:
        origin, ref, path = "https://github.com/" + "/".join(parts[:2]), parts[2], "/".join(parts[3:])
    elif "-" in parts:
        marker = parts.index("-")
        if marker >= 2 and parts[marker + 1:marker + 2] == ["raw"] and len(parts) > marker + 3:
            origin = parsed.scheme + "://" + parsed.netloc + "/" + "/".join(parts[:marker])
            ref, path = parts[marker + 2], "/".join(parts[marker + 3:])
    if origin is None or (url != DEFAULT_UPDATE_URL and origin not in {item["url"] for item in values}):
        return [url]
    results = []
    for item in values:
        base = item["url"]
        branch = urllib.parse.quote(item["branch"], safe="") if item["branch"] else ref
        if base.startswith("https://gitee.com/"):
            address = base + "/raw/" + branch + "/" + path
        elif base.startswith("https://github.com/"):
            address = base.replace("https://github.com/", "https://raw.githubusercontent.com/", 1) + "/" + branch + "/" + path
        else:
            address = base + "/-/raw/" + branch + "/" + path
        results.append(address)
    return results


def check_release(url, install, current, repositories=None):
    failures = []
    for address in mirror_locations(url, repositories):
        try:
            logging.getLogger("publish-switcher").info("查询程序更新地址：%s", address)
            source, location = remote_file(address)
            release = validate_release(json.loads(source.metadata(location).decode("utf-8-sig")))
            release = remember_release(release, install, current)
            if repositories:
                release[0]["mirror_repositories"] = repositories
            return release
        except Exception as exc:
            if not repositories:
                raise
            failures.append(address + "：" + str(exc))
            logging.getLogger("publish-switcher").warning("程序更新地址不可用：%s；%s", address, exc)
    raise UpdateError("程序更新地址均不可用：\n" + "\n".join(failures))


def remember_release(release, install, current):
    state = update_state(install)
    required = state / "required.json"
    if required.exists() and version_number(release["version"]) < version_number(read_json(required)["version"]):
        raise UpdateError("更新源返回的版本低于此前检查到的版本，请联系实施人员。")
    save_json(required, release)
    return release, version_number(release["version"]) > version_number(current)


def package_version(path):
    tree = ast.parse(Path(path).read_text(encoding="utf-8-sig"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "VERSION" for t in node.targets):
            value = ast.literal_eval(node.value)
            version_number(value)
            return value
    raise UpdateError("更新包缺少程序版本。")


def prepare_package(install, release, package, current):
    install, package = Path(install).absolute(), Path(package)
    release = validate_release(release)
    state = update_state(install)
    if version_number(release["version"]) < version_number(current):
        raise UpdateError("不能用较旧的安装包更新程序。")
    required = state / "required.json"
    if required.exists() and version_number(release["version"]) < version_number(read_json(required)["version"]):
        raise UpdateError("此离线包低于已知的必更版本，请准备最新安装包。")
    if package.stat().st_size != release["size"]:
        raise UpdateError("程序更新包大小不匹配。")
    digest = hashlib.sha256()
    with package.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest() != release["sha256"]:
        raise UpdateError("程序更新包 SHA-256 校验失败。")
    if (state / "pending.json").exists():
        raise UpdateError("存在未完成的程序更新，请关闭并重新打开工具。")
    if not install.is_dir() or os.path.ismount(install):
        raise UpdateError("程序安装目录不存在或是挂载点，无法整体替换。")
    token = uuid.uuid4().hex
    stage = state / ("stage-" + token)
    stage.mkdir()
    try:
        with zipfile.ZipFile(package) as archive:
            entries = archive.infolist()
            if len(entries) > 10000 or sum(e.file_size for e in entries) > 1024 ** 3:
                raise UpdateError("程序更新包展开后过大。")
            required_space = sum(((entry.file_size + 4095) // 4096 + 1) * 4096 for entry in entries)
            if shutil.disk_usage(install.parent).free < required_space:
                raise UpdateError("程序更新磁盘空间不足。")
            seen = set()
            for entry in entries:
                raw_name = entry.orig_filename
                path = PurePosixPath(raw_name)
                mode = entry.external_attr >> 16
                if (not path.parts or path.parts[0] != "publish-switcher" or path.is_absolute()
                        or ".." in path.parts or "\\" in raw_name or ":" in raw_name
                        or stat.S_ISLNK(mode) or stat.S_IFMT(mode) not in (0, stat.S_IFDIR, stat.S_IFREG)):
                    raise UpdateError("程序更新包包含无效路径或特殊文件。")
                relative = path.parts[1:]
                if not relative:
                    continue
                key = "/".join(relative).casefold()
                if key in seen:
                    raise UpdateError("程序更新包包含重复路径。")
                seen.add(key)
                destination = stage.joinpath(*relative)
                if entry.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                else:
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(entry) as incoming, destination.open("xb") as outgoing:
                        shutil.copyfileobj(incoming, outgoing)
                        outgoing.flush()
                        os.fsync(outgoing.fileno())
                    destination.chmod(0o755 if mode & 0o111 else 0o644)
        if any(not (stage / name).is_file() for name in REQUIRED_FILES):
            raise UpdateError("更新包缺少完整的 Switcher 程序文件。")
        for module in stage.glob("*.py"):
            compile(module.read_bytes(), str(module), "exec")
        if package_version(stage / "version.py") != release["version"]:
            raise UpdateError("更新信息与安装包内的版本不一致。")
        record = {"phase": "prepared", "stage": stage.name, "backup": "backup-" + token, "version": release["version"]}
        save_json(state / "pending.json", record)
        return record
    except BaseException:
        shutil.rmtree(stage)
        raise


def prepare_online(install, release, current, cancel, progress):
    state = update_state(install)
    package = state / "download.zip"
    failures = []
    addresses = mirror_locations(release["url"], release.get("mirror_repositories"))
    for address in addresses:
        try:
            source, location = remote_file(address)
            source.download(location, package, release["size"], release["sha256"], cancel, progress)
            break
        except Exception as exc:
            from core import Cancelled
            if isinstance(exc, Cancelled) or not release.get("mirror_repositories"):
                raise
            failures.append(address + "：" + str(exc))
            logging.getLogger("publish-switcher").warning("程序包地址不可用：%s；%s", address, exc)
    else:
        raise UpdateError("程序包下载地址均不可用：\n" + "\n".join(failures))
    return prepare_package(install, release, package, current)


def prepare_offline(install, manifest, current):
    manifest = Path(manifest)
    release = validate_release(read_json(manifest))
    return prepare_package(install, release, manifest.parent / release["package_file"], current)


def pending_paths(install):
    state = update_state(install)
    record = read_json(state / "pending.json")
    for key in ("stage", "backup"):
        if not re.fullmatch(key + r"-[0-9a-f]{32}", record.get(key, "")):
            raise UpdateError("程序更新恢复记录路径无效。")
        if (state / record[key]).is_symlink():
            raise UpdateError("程序更新目录不能是符号链接。")
    return state, record, state / record["stage"], state / record["backup"]


def recover_update(install):
    install = Path(install).absolute()
    state = update_state(install)
    if not (state / "pending.json").exists():
        return
    state, record, stage, backup = pending_paths(install)
    if record["phase"] != "committed" and backup.is_dir():
        if install.exists():
            os.replace(install, state / ("failed-" + uuid.uuid4().hex))
        os.replace(backup, install)
        sync_directory(install.parent)
        sync_directory(state)
    if not install.is_dir():
        raise UpdateError("程序更新恢复失败，请从完整安装包恢复工具目录。")
    if stage.is_dir():
        shutil.rmtree(stage)
    (state / "pending.json").unlink()


def commit_update(install):
    install = Path(install).absolute()
    state, record, stage, backup = pending_paths(install)
    if record["phase"] != "prepared" or not stage.is_dir():
        raise UpdateError("程序更新准备记录无效。")
    try:
        os.replace(install, backup)
        sync_directory(install.parent)
        sync_directory(state)
        record["phase"] = "backed_up"
        save_json(state / "pending.json", record)
        os.replace(stage, install)
        sync_directory(install.parent)
        sync_directory(state)
        probe = subprocess.run([sys.executable, "-B", str(install / "switcher.py"), "--version"],
                               cwd=str(install.parent), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               encoding="utf-8", errors="replace", timeout=30)
        if probe.returncode or probe.stdout.strip() != "Publish Switcher " + record["version"]:
            raise UpdateError("新版启动校验失败：" + probe.stderr[-2000:])
        record["phase"] = "committed"
        save_json(state / "pending.json", record)
        save_json(state / "last-update.json", {"version": record["version"], "backup": str(backup), "error": None})
        (state / "pending.json").unlink()
    except BaseException as exc:
        recover_update(install)
        save_json(state / "last-update.json", {"error": str(exc)})
        raise


def launch_update_helper(install, engineer=False):
    state = update_state(install)
    helper = state / "apply-update.py"
    shutil.copyfile(Path(__file__), helper)
    command = [sys.executable, "-B", str(helper), "--apply", str(Path(install).absolute())]
    if engineer:
        command.append("--engineer")
    options = {"start_new_session": True} if os.name == "posix" else {"creationflags": subprocess.CREATE_NO_WINDOW}
    with (state / "helper.log").open("a", encoding="utf-8") as log:
        return subprocess.Popen(command, cwd=str(state), stdout=log, stderr=log, **options)


def helper_main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--apply")
    action.add_argument("--launch")
    parser.add_argument("--engineer", action="store_true")
    args = parser.parse_args()
    install = Path(args.apply or args.launch)
    with instance_lock(install, timeout=90):
        if args.launch:
            recover_update(install)
        else:
            error = None
            try:
                commit_update(install)
            except Exception as exc:
                error = str(exc)
                print(str(exc), file=sys.stderr, flush=True)
            # The publish deployment is independent and remains committed on tool failure.
            summary = update_state(install) / "combined-update.json"
            if summary.exists():
                try:
                    result = read_json(summary)
                    if result.get("phase") == "restarting":
                        result.update(program="更新失败，已恢复旧版" if error else "更新成功",
                                      success=not bool(error), restart=False,
                                      phase="failed" if error else "complete")
                        if error:
                            result["error"] = error
                        save_json(summary, result)
                except (OSError, ValueError, TypeError):
                    print("无法保存组合更新结果，请查看 last-update.json 和 helper.log。", file=sys.stderr, flush=True)
    command = [sys.executable, str(install / "switcher.py"), "gui"]
    if args.engineer:
        command.append("--engineer")
    os.chdir(install)
    os.execv(sys.executable, command)


if __name__ == "__main__":
    helper_main()
