print("permissions sample")
