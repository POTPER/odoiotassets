print("local")
