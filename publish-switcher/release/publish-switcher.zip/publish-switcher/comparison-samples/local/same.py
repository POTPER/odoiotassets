print("same")
