print("complete resource")
