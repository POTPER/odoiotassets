print("remote")
